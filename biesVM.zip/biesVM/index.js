import parseToInstructions from './src/parser.js';

const input = `print(666);`; // Cambia esto por el código que quieres probar.
const tree = parseToInstructions(input);

